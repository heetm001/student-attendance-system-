"""
Student Attendance Management System  (DBMS Mini Project)
Tables : Students, Courses, Attendance_Logs, Faculty
Purpose: Record course-wise attendance daily and calculate
         percentage criteria per student.

Run   : python main.py        (Python 3.8+, no extra packages needed)
"""
import os
import random
import sqlite3
from datetime import date, timedelta

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "attendance.db")
MIN_PERCENT = 75  # attendance criteria


# ---------------------------------------------------------------- database
def get_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def read_sql(name):
    with open(os.path.join(BASE_DIR, name), encoding="utf-8") as f:
        return f.read()


def init_db(conn):
    """Create tables/view; load sample data the first time."""
    conn.executescript(read_sql("schema.sql"))
    if conn.execute("SELECT COUNT(*) FROM Students").fetchone()[0] == 0:
        conn.executescript(read_sql("sample_data.sql"))
        seed_attendance(conn)
        conn.commit()
        print("Sample data loaded (8 students, 4 courses, 3 faculty, 12 days of attendance).")


def seed_attendance(conn):
    """Generate 12 working days of attendance so reports have data."""
    random.seed(42)
    days, d = [], date.today() - timedelta(days=1)
    while len(days) < 12:
        if d.weekday() < 5:  # Mon-Fri
            days.append(d)
        d -= timedelta(days=1)
    chance = {r["student_id"]: random.uniform(0.55, 0.98)
              for r in conn.execute("SELECT student_id FROM Students")}
    for c in conn.execute("SELECT * FROM Courses").fetchall():
        studs = conn.execute("SELECT student_id FROM Students WHERE department=? AND semester=?",
                             (c["department"], c["semester"])).fetchall()
        for day in days:
            for s in studs:
                status = "Present" if random.random() < chance[s["student_id"]] else "Absent"
                conn.execute("INSERT INTO Attendance_Logs "
                             "(student_id, course_id, marked_by, attendance_date, status) "
                             "VALUES (?,?,?,?,?)",
                             (s["student_id"], c["course_id"], c["faculty_id"], day.isoformat(), status))


# ----------------------------------------------------------------- helpers
def show_table(rows, headers=None):
    if not rows:
        print("  (no records)")
        return
    rows = [list(r) for r in rows]
    data = [[("" if v is None else str(v)) for v in r] for r in rows]
    widths = [max(len(str(h)), *(len(r[i]) for r in data)) for i, h in enumerate(headers)]
    line = "+-" + "-+-".join("-" * w for w in widths) + "-+"
    print(line)
    print("| " + " | ".join(str(h).ljust(w) for h, w in zip(headers, widths)) + " |")
    print(line)
    for r in data:
        print("| " + " | ".join(v.ljust(w) for v, w in zip(r, widths)) + " |")
    print(line)


def query(conn, sql, params=()):
    cur = conn.execute(sql, params)
    rows = cur.fetchall()
    headers = [d[0] for d in cur.description]
    show_table([tuple(r) for r in rows], headers)


def ask(prompt, default=None):
    text = f"{prompt}" + (f" [{default}]" if default else "") + ": "
    val = input(text).strip()
    return val or (default or "")


def ask_int(prompt, default=None):
    while True:
        val = ask(prompt, str(default) if default is not None else None)
        if val.lstrip("-").isdigit():
            return int(val)
        print("  Please enter a number.")


def ask_date(prompt):
    while True:
        val = ask(prompt, date.today().isoformat())
        try:
            return date.fromisoformat(val).isoformat()
        except ValueError:
            print("  Use format YYYY-MM-DD.")


def find_course(conn, code):
    return conn.execute("SELECT * FROM Courses WHERE course_code = ?", (code.upper(),)).fetchone()


# ---------------------------------------------------------------- features
def add_faculty(conn):
    name = ask("Faculty name")
    email = ask("Email")
    dept = ask("Department")
    try:
        conn.execute("INSERT INTO Faculty (name, email, department) VALUES (?,?,?)", (name, email, dept))
        conn.commit()
        print("  Faculty added.")
    except sqlite3.IntegrityError as e:
        print("  Could not add faculty:", e)


def add_student(conn):
    roll = ask("Roll no").upper()
    name = ask("Student name")
    email = ask("Email")
    dept = ask("Department", "Electrical Engineering")
    sem = ask_int("Semester (1-8)")
    try:
        conn.execute("INSERT INTO Students (roll_no, name, email, department, semester) VALUES (?,?,?,?,?)",
                     (roll, name, email or None, dept, sem))
        conn.commit()
        print("  Student added.")
    except sqlite3.IntegrityError as e:
        print("  Could not add student:", e)


def add_course(conn):
    print("Available faculty:")
    query(conn, "SELECT faculty_id, name, department FROM Faculty")
    code = ask("Course code").upper()
    name = ask("Course name")
    credits = ask_int("Credits")
    dept = ask("Department", "Electrical Engineering")
    sem = ask_int("Semester (1-8)")
    fid = ask_int("Faculty id")
    try:
        conn.execute("INSERT INTO Courses (course_code, course_name, credits, department, semester, faculty_id) "
                     "VALUES (?,?,?,?,?,?)", (code, name, credits, dept, sem, fid))
        conn.commit()
        print("  Course added.")
    except sqlite3.IntegrityError as e:
        print("  Could not add course:", e)


def mark_attendance(conn):
    query(conn, "SELECT c.course_code, c.course_name, f.name AS faculty "
                "FROM Courses c JOIN Faculty f ON f.faculty_id = c.faculty_id")
    course = find_course(conn, ask("Course code"))
    if not course:
        print("  Course not found.")
        return
    day = ask_date("Date")
    students = conn.execute("SELECT * FROM Students WHERE department=? AND semester=? ORDER BY roll_no",
                            (course["department"], course["semester"])).fetchall()
    if not students:
        print("  No students are enrolled for this course (department/semester).")
        return
    print(f"\nStudents in {course['course_code']} - {course['course_name']}:")
    show_table([(s["roll_no"], s["name"]) for s in students], ["Roll No", "Name"])
    raw = ask("Enter ABSENT roll numbers separated by comma (blank = everyone present)")
    absent = {r.strip().upper() for r in raw.split(",") if r.strip()}
    valid = {s["roll_no"] for s in students}
    if absent - valid:
        print("  Unknown roll numbers:", ", ".join(sorted(absent - valid)), "- nothing saved.")
        return
    for s in students:
        status = "Absent" if s["roll_no"] in absent else "Present"
        conn.execute(
            "INSERT INTO Attendance_Logs (student_id, course_id, marked_by, attendance_date, status) "
            "VALUES (?,?,?,?,?) "
            "ON CONFLICT(student_id, course_id, attendance_date) DO UPDATE SET status = excluded.status",
            (s["student_id"], course["course_id"], course["faculty_id"], day, status))
    conn.commit()
    print(f"  Attendance saved for {len(students)} students "
          f"({len(students) - len(absent)} present, {len(absent)} absent) on {day}.")


def view_day_attendance(conn):
    course = find_course(conn, ask("Course code"))
    if not course:
        print("  Course not found.")
        return
    day = ask_date("Date")
    query(conn, "SELECT s.roll_no, s.name, al.status FROM Attendance_Logs al "
                "JOIN Students s ON s.student_id = al.student_id "
                "WHERE al.course_id = ? AND al.attendance_date = ? ORDER BY s.roll_no",
          (course["course_id"], day))


def student_report(conn):
    roll = ask("Student roll no").upper()
    stu = conn.execute("SELECT * FROM Students WHERE roll_no = ?", (roll,)).fetchone()
    if not stu:
        print("  Student not found.")
        return
    print(f"\nAttendance report: {stu['roll_no']} - {stu['name']}")
    query(conn, "SELECT course_code, course_name, total_classes AS total, classes_attended AS attended, "
                "percentage AS 'percent', criteria_status AS status "
                "FROM v_attendance_summary WHERE student_id = ? ORDER BY course_code", (stu["student_id"],))
    row = conn.execute("SELECT SUM(total_classes) t, SUM(classes_attended) a "
                       "FROM v_attendance_summary WHERE student_id = ?", (stu["student_id"],)).fetchone()
    if row["t"]:
        overall = round(100.0 * row["a"] / row["t"], 2)
        verdict = "ELIGIBLE" if overall >= MIN_PERCENT else "SHORTAGE"
        print(f"Overall attendance: {overall}%  ->  {verdict} (criteria {MIN_PERCENT}%)")


def course_report(conn):
    course = find_course(conn, ask("Course code"))
    if not course:
        print("  Course not found.")
        return
    print(f"\nCourse report: {course['course_code']} - {course['course_name']}")
    query(conn, "SELECT roll_no, student_name AS name, total_classes AS total, classes_attended AS attended, "
                "percentage AS 'percent', criteria_status AS status "
                "FROM v_attendance_summary WHERE course_id = ? ORDER BY percentage DESC", (course["course_id"],))


def defaulters(conn):
    print(f"\nStudents below {MIN_PERCENT}% attendance:")
    query(conn, "SELECT roll_no, student_name AS name, course_code, percentage AS 'percent', "
                "criteria_status AS status FROM v_attendance_summary "
                "WHERE percentage < ? ORDER BY percentage", (MIN_PERCENT,))


def list_master(conn):
    print("\nFACULTY");  query(conn, "SELECT * FROM Faculty")
    print("\nSTUDENTS"); query(conn, "SELECT * FROM Students")
    print("\nCOURSES");  query(conn, "SELECT c.course_id, c.course_code, c.course_name, c.credits, "
                                    "c.semester, f.name AS faculty FROM Courses c "
                                    "JOIN Faculty f ON f.faculty_id = c.faculty_id")


# -------------------------------------------------------------------- menu
MENU = [
    ("Mark daily attendance (course-wise)", mark_attendance),
    ("View attendance of a course on a date", view_day_attendance),
    ("Student attendance report (percentage)", student_report),
    ("Course attendance report", course_report),
    ("Defaulter list (below 75%)", defaulters),
    ("Add student", add_student),
    ("Add faculty", add_faculty),
    ("Add course", add_course),
    ("List faculty / students / courses", list_master),
]


def main():
    conn = get_connection()
    init_db(conn)
    while True:
        print("\n=========== STUDENT ATTENDANCE MANAGEMENT SYSTEM ===========")
        for i, (label, _) in enumerate(MENU, 1):
            print(f" {i}. {label}")
        print(" 0. Exit")
        choice = input("Choose an option: ").strip()
        if choice == "0":
            print("Goodbye!")
            break
        if choice.isdigit() and 1 <= int(choice) <= len(MENU):
            print()
            MENU[int(choice) - 1][1](conn)
        else:
            print("Invalid option.")
    conn.close()


if __name__ == "__main__":
    main()
