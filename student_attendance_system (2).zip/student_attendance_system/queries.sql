-- Useful SQL queries (run in VS Code with the "SQLite" extension, or any SQLite tool)

-- 1. Attendance percentage of every student in every course
SELECT roll_no, student_name, course_code, total_classes, classes_attended, percentage, criteria_status
FROM v_attendance_summary
ORDER BY roll_no, course_code;

-- 2. Overall attendance percentage per student (all courses combined)
SELECT s.roll_no, s.name,
       COUNT(*) AS total_classes,
       SUM(al.status = 'Present') AS attended,
       ROUND(100.0 * SUM(al.status = 'Present') / COUNT(*), 2) AS overall_percentage
FROM Attendance_Logs al
JOIN Students s ON s.student_id = al.student_id
GROUP BY s.student_id
ORDER BY overall_percentage;

-- 3. Defaulters: students below 75% in any course
SELECT roll_no, student_name, course_code, percentage, criteria_status
FROM v_attendance_summary
WHERE percentage < 75
ORDER BY percentage;

-- 4. Course-wise average attendance
SELECT course_code, course_name, ROUND(AVG(percentage), 2) AS avg_percentage
FROM v_attendance_summary
GROUP BY course_id;

-- 5. Who is absent on a given day for a given course
SELECT s.roll_no, s.name, c.course_code, al.attendance_date
FROM Attendance_Logs al
JOIN Students s ON s.student_id = al.student_id
JOIN Courses  c ON c.course_id  = al.course_id
WHERE al.status = 'Absent' AND c.course_code = 'EE501' AND al.attendance_date = '2026-10-23';

-- 6. Courses taught by each faculty
SELECT f.name AS faculty, c.course_code, c.course_name
FROM Faculty f JOIN Courses c ON c.faculty_id = f.faculty_id
ORDER BY f.name;

-- 7. How many more classes a student must attend continuously to reach 75%
--    (x = (0.75*total - attended) / 0.25)
SELECT roll_no, course_code, percentage,
       CASE WHEN percentage >= 75 THEN 0
            ELSE CAST(((0.75 * total_classes - classes_attended) / 0.25) + 0.9999 AS INTEGER)
       END AS classes_needed_for_75
FROM v_attendance_summary
ORDER BY classes_needed_for_75 DESC;
