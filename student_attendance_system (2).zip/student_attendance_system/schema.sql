-- =====================================================
-- Student Attendance Management System  (DBMS Project)
-- Tables : Students, Courses, Attendance_Logs, Faculty
-- Purpose: Record course-wise attendance daily and
--          calculate percentage criteria per student.
-- =====================================================

PRAGMA foreign_keys = ON;

-- 1. FACULTY ------------------------------------------
CREATE TABLE IF NOT EXISTS Faculty (
    faculty_id   INTEGER PRIMARY KEY AUTOINCREMENT,
    name         TEXT NOT NULL,
    email        TEXT NOT NULL UNIQUE,
    department   TEXT NOT NULL
);

-- 2. STUDENTS -----------------------------------------
CREATE TABLE IF NOT EXISTS Students (
    student_id   INTEGER PRIMARY KEY AUTOINCREMENT,
    roll_no      TEXT NOT NULL UNIQUE,
    name         TEXT NOT NULL,
    email        TEXT UNIQUE,
    department   TEXT NOT NULL,
    semester     INTEGER NOT NULL CHECK (semester BETWEEN 1 AND 8)
);

-- 3. COURSES (each course is taught by one faculty) ---
--    A student belongs to a course when the student's
--    department and semester match the course's.
CREATE TABLE IF NOT EXISTS Courses (
    course_id    INTEGER PRIMARY KEY AUTOINCREMENT,
    course_code  TEXT NOT NULL UNIQUE,
    course_name  TEXT NOT NULL,
    credits      INTEGER NOT NULL CHECK (credits > 0),
    department   TEXT NOT NULL,
    semester     INTEGER NOT NULL CHECK (semester BETWEEN 1 AND 8),
    faculty_id   INTEGER NOT NULL,
    FOREIGN KEY (faculty_id) REFERENCES Faculty(faculty_id)
        ON UPDATE CASCADE ON DELETE RESTRICT
);

-- 4. ATTENDANCE_LOGS (one row per student/course/day) -
CREATE TABLE IF NOT EXISTS Attendance_Logs (
    log_id           INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id       INTEGER NOT NULL,
    course_id        INTEGER NOT NULL,
    marked_by        INTEGER NOT NULL,              -- faculty who marked it
    attendance_date  TEXT NOT NULL,                 -- YYYY-MM-DD
    status           TEXT NOT NULL CHECK (status IN ('Present', 'Absent')),
    FOREIGN KEY (student_id) REFERENCES Students(student_id)
        ON UPDATE CASCADE ON DELETE CASCADE,
    FOREIGN KEY (course_id)  REFERENCES Courses(course_id)
        ON UPDATE CASCADE ON DELETE CASCADE,
    FOREIGN KEY (marked_by)  REFERENCES Faculty(faculty_id)
        ON UPDATE CASCADE ON DELETE RESTRICT,
    UNIQUE (student_id, course_id, attendance_date)  -- no duplicate entry for a day
);

CREATE INDEX IF NOT EXISTS idx_att_course_date ON Attendance_Logs(course_id, attendance_date);
CREATE INDEX IF NOT EXISTS idx_att_student     ON Attendance_Logs(student_id);

-- 5. VIEW: percentage per student per course ----------
--    >= 75%        -> Eligible
--    65% to < 75%  -> Condonation (warning)
--    < 65%         -> Detained
DROP VIEW IF EXISTS v_attendance_summary;
CREATE VIEW v_attendance_summary AS
SELECT
    s.student_id,
    s.roll_no,
    s.name                                            AS student_name,
    c.course_id,
    c.course_code,
    c.course_name,
    COUNT(*)                                          AS total_classes,
    SUM(CASE WHEN al.status = 'Present' THEN 1 ELSE 0 END) AS classes_attended,
    ROUND(100.0 * SUM(CASE WHEN al.status = 'Present' THEN 1 ELSE 0 END) / COUNT(*), 2)
                                                      AS percentage,
    CASE
        WHEN 100.0 * SUM(CASE WHEN al.status = 'Present' THEN 1 ELSE 0 END) / COUNT(*) >= 75 THEN 'Eligible'
        WHEN 100.0 * SUM(CASE WHEN al.status = 'Present' THEN 1 ELSE 0 END) / COUNT(*) >= 65 THEN 'Condonation'
        ELSE 'Detained'
    END                                               AS criteria_status
FROM Attendance_Logs al
JOIN Students s ON s.student_id = al.student_id
JOIN Courses  c ON c.course_id  = al.course_id
GROUP BY s.student_id, c.course_id;
