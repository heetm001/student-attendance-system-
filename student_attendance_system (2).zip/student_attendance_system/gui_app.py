"""
Student Attendance Management System - GUI (Tkinter + SQLite)
DBMS Mini Project

Run : python gui_app.py        (Python 3.8+, Tkinter comes with Python)
Uses the same database (attendance.db) and schema as main.py
"""
import sqlite3
import tkinter as tk
from datetime import date
from tkinter import messagebox, ttk

from main import MIN_PERCENT, get_connection, init_db

STATUS_COLORS = {"Eligible": "#d4f4dd", "Condonation": "#fff0c2", "Detained": "#fbd0d0",
                 "Present": "#d4f4dd", "Absent": "#fbd0d0"}


class AttendanceApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Student Attendance Management System")
        self.geometry("1000x640")
        self.minsize(900, 560)
        self.conn = get_connection()
        init_db(self.conn)

        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure("Title.TLabel", font=("Segoe UI", 16, "bold"), foreground="#1f3a5f")
        style.configure("TNotebook.Tab", padding=(14, 6), font=("Segoe UI", 10, "bold"))
        style.configure("Treeview", rowheight=26, font=("Segoe UI", 10))
        style.configure("Treeview.Heading", font=("Segoe UI", 10, "bold"))

        ttk.Label(self, text="Student Attendance Management System", style="Title.TLabel").pack(pady=(10, 4))
        self.notebook = ttk.Notebook(self)
        self.notebook.pack(fill="both", expand=True, padx=10, pady=(0, 10))

        self.build_mark_tab()
        self.build_student_tab()
        self.build_course_tab()
        self.build_defaulter_tab()
        self.build_manage_tab()
        self.build_records_tab()

        self.notebook.bind("<<NotebookTabChanged>>", lambda e: self.refresh_all())
        self.refresh_all()

    # ------------------------------------------------------------ helpers
    def make_tree(self, parent):
        frame = ttk.Frame(parent)
        tree = ttk.Treeview(frame, show="headings", selectmode="browse")
        vsb = ttk.Scrollbar(frame, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=vsb.set)
        tree.pack(side="left", fill="both", expand=True)
        vsb.pack(side="right", fill="y")
        for name, color in STATUS_COLORS.items():
            tree.tag_configure(name, background=color)
        return frame, tree

    def fill_tree(self, tree, headers, rows, status_index=None):
        tree.delete(*tree.get_children())
        tree["columns"] = headers
        for h in headers:
            tree.heading(h, text=h)
            tree.column(h, anchor="center", width=110, minwidth=70)
        for r in rows:
            tag = ()
            if status_index is not None and str(r[status_index]) in STATUS_COLORS:
                tag = (str(r[status_index]),)
            tree.insert("", "end", values=[("" if v is None else v) for v in r], tags=tag)

    def run_query(self, sql, params=()):
        cur = self.conn.execute(sql, params)
        rows = [tuple(r) for r in cur.fetchall()]
        return [d[0] for d in cur.description], rows

    def course_options(self):
        return [f"{r['course_code']} - {r['course_name']}"
                for r in self.conn.execute("SELECT * FROM Courses ORDER BY course_code")]

    def student_options(self):
        return [f"{r['roll_no']} - {r['name']}"
                for r in self.conn.execute("SELECT * FROM Students ORDER BY roll_no")]

    def faculty_options(self):
        return [f"{r['faculty_id']} - {r['name']}"
                for r in self.conn.execute("SELECT * FROM Faculty ORDER BY faculty_id")]

    @staticmethod
    def code_of(text):
        return text.split(" - ")[0].strip()

    def get_course(self, text):
        return self.conn.execute("SELECT * FROM Courses WHERE course_code = ?",
                                 (self.code_of(text).upper(),)).fetchone()

    def valid_date(self, text):
        try:
            return date.fromisoformat(text.strip()).isoformat()
        except ValueError:
            messagebox.showerror("Invalid date", "Enter date as YYYY-MM-DD (e.g. 2026-10-24).")
            return None

    # ----------------------------------------------------- tab 1: mark attendance
    def build_mark_tab(self):
        tab = ttk.Frame(self.notebook, padding=10)
        self.notebook.add(tab, text="Mark Attendance")
        top = ttk.Frame(tab)
        top.pack(fill="x")
        ttk.Label(top, text="Course:").pack(side="left")
        self.mark_course = ttk.Combobox(top, state="readonly", width=34)
        self.mark_course.pack(side="left", padx=6)
        ttk.Label(top, text="Date (YYYY-MM-DD):").pack(side="left", padx=(12, 0))
        self.mark_date = ttk.Entry(top, width=12)
        self.mark_date.insert(0, date.today().isoformat())
        self.mark_date.pack(side="left", padx=6)
        ttk.Button(top, text="Load Students", command=self.load_mark_students).pack(side="left", padx=6)

        frame, self.mark_tree = self.make_tree(tab)
        frame.pack(fill="both", expand=True, pady=10)
        self.fill_tree(self.mark_tree, ("Roll No", "Name", "Status"), [])
        self.mark_tree.bind("<Double-1>", lambda e: self.toggle_selected())

        bottom = ttk.Frame(tab)
        bottom.pack(fill="x")
        ttk.Button(bottom, text="Toggle Selected (or double-click)", command=self.toggle_selected).pack(side="left")
        ttk.Button(bottom, text="All Present", command=lambda: self.set_all("Present")).pack(side="left", padx=6)
        ttk.Button(bottom, text="All Absent", command=lambda: self.set_all("Absent")).pack(side="left")
        self.mark_count = ttk.Label(bottom, text="")
        self.mark_count.pack(side="left", padx=16)
        ttk.Button(bottom, text="Save Attendance", command=self.save_attendance).pack(side="right")

    def load_mark_students(self):
        course = self.get_course(self.mark_course.get()) if self.mark_course.get() else None
        day = self.valid_date(self.mark_date.get())
        if not course:
            messagebox.showwarning("Select course", "Please select a course first.")
            return
        if not day:
            return
        rows = self.conn.execute(
            "SELECT s.student_id, s.roll_no, s.name, "
            "COALESCE((SELECT status FROM Attendance_Logs al WHERE al.student_id = s.student_id "
            "AND al.course_id = ? AND al.attendance_date = ?), 'Present') AS status "
            "FROM Students s WHERE s.department = ? AND s.semester = ? ORDER BY s.roll_no",
            (course["course_id"], day, course["department"], course["semester"])).fetchall()
        self.fill_tree(self.mark_tree, ("Roll No", "Name", "Status"),
                       [(r["roll_no"], r["name"], r["status"]) for r in rows], status_index=2)
        if not rows:
            messagebox.showinfo("No students", "No students match this course's department/semester.")
        self.update_mark_count()

    def toggle_selected(self):
        sel = self.mark_tree.selection()
        if not sel:
            return
        vals = list(self.mark_tree.item(sel[0], "values"))
        vals[2] = "Absent" if vals[2] == "Present" else "Present"
        self.mark_tree.item(sel[0], values=vals, tags=(vals[2],))
        self.update_mark_count()

    def set_all(self, status):
        for iid in self.mark_tree.get_children():
            vals = list(self.mark_tree.item(iid, "values"))
            vals[2] = status
            self.mark_tree.item(iid, values=vals, tags=(status,))
        self.update_mark_count()

    def update_mark_count(self):
        items = [self.mark_tree.item(i, "values") for i in self.mark_tree.get_children()]
        present = sum(1 for v in items if v[2] == "Present")
        self.mark_count.config(text=f"Present: {present}   Absent: {len(items) - present}")

    def save_attendance(self):
        course = self.get_course(self.mark_course.get()) if self.mark_course.get() else None
        day = self.valid_date(self.mark_date.get())
        items = [self.mark_tree.item(i, "values") for i in self.mark_tree.get_children()]
        if not course or not day or not items:
            messagebox.showwarning("Nothing to save", "Select a course, date and click Load Students first.")
            return
        try:
            for roll, _name, status in items:
                stu = self.conn.execute("SELECT student_id FROM Students WHERE roll_no = ?", (roll,)).fetchone()
                self.conn.execute(
                    "INSERT INTO Attendance_Logs (student_id, course_id, marked_by, attendance_date, status) "
                    "VALUES (?,?,?,?,?) ON CONFLICT(student_id, course_id, attendance_date) "
                    "DO UPDATE SET status = excluded.status",
                    (stu["student_id"], course["course_id"], course["faculty_id"], day, status))
            self.conn.commit()
        except sqlite3.Error as e:
            self.conn.rollback()
            messagebox.showerror("Database error", str(e))
            return
        messagebox.showinfo("Saved", f"Attendance saved for {len(items)} students on {day}.")

    # ----------------------------------------------------- tab 2: student report
    def build_student_tab(self):
        tab = ttk.Frame(self.notebook, padding=10)
        self.notebook.add(tab, text="Student Report")
        top = ttk.Frame(tab)
        top.pack(fill="x")
        ttk.Label(top, text="Student:").pack(side="left")
        self.stu_cb = ttk.Combobox(top, state="readonly", width=34)
        self.stu_cb.pack(side="left", padx=6)
        self.stu_cb.bind("<<ComboboxSelected>>", lambda e: self.show_student_report())
        ttk.Button(top, text="Show Report", command=self.show_student_report).pack(side="left", padx=6)
        frame, self.stu_tree = self.make_tree(tab)
        frame.pack(fill="both", expand=True, pady=10)
        self.stu_overall = ttk.Label(tab, text="", font=("Segoe UI", 12, "bold"))
        self.stu_overall.pack(anchor="w")

    def show_student_report(self):
        if not self.stu_cb.get():
            return
        roll = self.code_of(self.stu_cb.get())
        headers, rows = self.run_query(
            "SELECT course_code AS Course, course_name AS Name, total_classes AS Total, "
            "classes_attended AS Attended, percentage AS Percent, criteria_status AS Status "
            "FROM v_attendance_summary WHERE roll_no = ? ORDER BY course_code", (roll,))
        self.fill_tree(self.stu_tree, headers, rows, status_index=5)
        total = sum(r[2] for r in rows)
        attended = sum(r[3] for r in rows)
        if total:
            overall = round(100.0 * attended / total, 2)
            verdict = "ELIGIBLE" if overall >= MIN_PERCENT else "SHORTAGE"
            self.stu_overall.config(text=f"Overall attendance: {overall}%  ->  {verdict} (criteria {MIN_PERCENT}%)",
                                    foreground="#1a7f37" if overall >= MIN_PERCENT else "#c62828")
        else:
            self.stu_overall.config(text="No attendance recorded yet.", foreground="#444")

    # ----------------------------------------------------- tab 3: course report
    def build_course_tab(self):
        tab = ttk.Frame(self.notebook, padding=10)
        self.notebook.add(tab, text="Course Report")
        top = ttk.Frame(tab)
        top.pack(fill="x")
        ttk.Label(top, text="Course:").pack(side="left")
        self.crs_cb = ttk.Combobox(top, state="readonly", width=34)
        self.crs_cb.pack(side="left", padx=6)
        self.crs_cb.bind("<<ComboboxSelected>>", lambda e: self.show_course_report())
        ttk.Button(top, text="Show Report", command=self.show_course_report).pack(side="left", padx=6)
        frame, self.crs_tree = self.make_tree(tab)
        frame.pack(fill="both", expand=True, pady=10)

    def show_course_report(self):
        if not self.crs_cb.get():
            return
        code = self.code_of(self.crs_cb.get())
        headers, rows = self.run_query(
            "SELECT roll_no AS 'Roll No', student_name AS Name, total_classes AS Total, "
            "classes_attended AS Attended, percentage AS Percent, criteria_status AS Status "
            "FROM v_attendance_summary WHERE course_code = ? ORDER BY percentage DESC", (code,))
        self.fill_tree(self.crs_tree, headers, rows, status_index=5)

    # ----------------------------------------------------- tab 4: defaulters
    def build_defaulter_tab(self):
        tab = ttk.Frame(self.notebook, padding=10)
        self.notebook.add(tab, text="Defaulters")
        top = ttk.Frame(tab)
        top.pack(fill="x")
        ttk.Label(top, text=f"Students below {MIN_PERCENT}% attendance in any course",
                  font=("Segoe UI", 11, "bold")).pack(side="left")
        ttk.Button(top, text="Refresh", command=self.show_defaulters).pack(side="right")
        frame, self.def_tree = self.make_tree(tab)
        frame.pack(fill="both", expand=True, pady=10)

    def show_defaulters(self):
        headers, rows = self.run_query(
            "SELECT roll_no AS 'Roll No', student_name AS Name, course_code AS Course, "
            "classes_attended AS Attended, total_classes AS Total, percentage AS Percent, "
            "criteria_status AS Status FROM v_attendance_summary WHERE percentage < ? "
            "ORDER BY percentage", (MIN_PERCENT,))
        self.fill_tree(self.def_tree, headers, rows, status_index=6)

    # ----------------------------------------------------- tab 5: manage records
    def build_manage_tab(self):
        tab = ttk.Frame(self.notebook, padding=10)
        self.notebook.add(tab, text="Add Records")
        tab.columnconfigure((0, 1, 2), weight=1, uniform="col")

        # Student form
        f1 = ttk.LabelFrame(tab, text="Add Student", padding=10)
        f1.grid(row=0, column=0, sticky="nsew", padx=5)
        self.stu_form = self.make_form(f1, ["Roll No", "Name", "Email", "Department", "Semester (1-8)"])
        self.stu_form["Department"].insert(0, "Electrical Engineering")
        ttk.Button(f1, text="Add Student", command=self.add_student).pack(pady=8)

        # Faculty form
        f2 = ttk.LabelFrame(tab, text="Add Faculty", padding=10)
        f2.grid(row=0, column=1, sticky="nsew", padx=5)
        self.fac_form = self.make_form(f2, ["Name", "Email", "Department"])
        self.fac_form["Department"].insert(0, "Electrical Engineering")
        ttk.Button(f2, text="Add Faculty", command=self.add_faculty).pack(pady=8)

        # Course form
        f3 = ttk.LabelFrame(tab, text="Add Course", padding=10)
        f3.grid(row=0, column=2, sticky="nsew", padx=5)
        self.crs_form = self.make_form(f3, ["Course Code", "Course Name", "Credits", "Department", "Semester (1-8)"])
        self.crs_form["Department"].insert(0, "Electrical Engineering")
        ttk.Label(f3, text="Faculty").pack(anchor="w")
        self.crs_faculty = ttk.Combobox(f3, state="readonly")
        self.crs_faculty.pack(fill="x")
        ttk.Button(f3, text="Add Course", command=self.add_course).pack(pady=8)

    def make_form(self, parent, labels):
        entries = {}
        for label in labels:
            ttk.Label(parent, text=label).pack(anchor="w")
            e = ttk.Entry(parent)
            e.pack(fill="x", pady=(0, 4))
            entries[label] = e
        return entries

    @staticmethod
    def clear_form(form):
        for e in form.values():
            e.delete(0, "end")

    def insert_row(self, sql, params, success, form, defaults=None):
        try:
            self.conn.execute(sql, params)
            self.conn.commit()
        except sqlite3.IntegrityError as e:
            self.conn.rollback()
            messagebox.showerror("Could not save", f"Duplicate or invalid data:\n{e}")
            return
        self.clear_form(form)
        for k, v in (defaults or {}).items():
            form[k].insert(0, v)
        self.refresh_all()
        messagebox.showinfo("Saved", success)

    def add_student(self):
        f = {k: v.get().strip() for k, v in self.stu_form.items()}
        if not f["Roll No"] or not f["Name"] or not f["Department"] or not f["Semester (1-8)"].isdigit():
            messagebox.showwarning("Missing data", "Roll No, Name, Department and a numeric Semester are required.")
            return
        self.insert_row(
            "INSERT INTO Students (roll_no, name, email, department, semester) VALUES (?,?,?,?,?)",
            (f["Roll No"].upper(), f["Name"], f["Email"] or None, f["Department"], int(f["Semester (1-8)"])),
            "Student added.", self.stu_form, {"Department": "Electrical Engineering"})

    def add_faculty(self):
        f = {k: v.get().strip() for k, v in self.fac_form.items()}
        if not all(f.values()):
            messagebox.showwarning("Missing data", "All faculty fields are required.")
            return
        self.insert_row("INSERT INTO Faculty (name, email, department) VALUES (?,?,?)",
                        (f["Name"], f["Email"], f["Department"]),
                        "Faculty added.", self.fac_form, {"Department": "Electrical Engineering"})

    def add_course(self):
        f = {k: v.get().strip() for k, v in self.crs_form.items()}
        if (not all(f.values()) or not f["Credits"].isdigit() or not f["Semester (1-8)"].isdigit()
                or not self.crs_faculty.get()):
            messagebox.showwarning("Missing data", "Fill all fields (numeric credits/semester) and pick a faculty.")
            return
        self.insert_row(
            "INSERT INTO Courses (course_code, course_name, credits, department, semester, faculty_id) "
            "VALUES (?,?,?,?,?,?)",
            (f["Course Code"].upper(), f["Course Name"], int(f["Credits"]), f["Department"],
             int(f["Semester (1-8)"]), int(self.code_of(self.crs_faculty.get()))),
            "Course added.", self.crs_form, {"Department": "Electrical Engineering"})

    # ----------------------------------------------------- tab 6: records viewer
    def build_records_tab(self):
        tab = ttk.Frame(self.notebook, padding=10)
        self.notebook.add(tab, text="View Records")
        top = ttk.Frame(tab)
        top.pack(fill="x")
        ttk.Label(top, text="Table:").pack(side="left")
        self.rec_cb = ttk.Combobox(top, state="readonly", width=24,
                                   values=["Faculty", "Students", "Courses", "Attendance_Logs"])
        self.rec_cb.current(1)
        self.rec_cb.pack(side="left", padx=6)
        self.rec_cb.bind("<<ComboboxSelected>>", lambda e: self.show_records())
        ttk.Button(top, text="Refresh", command=self.show_records).pack(side="left")
        frame, self.rec_tree = self.make_tree(tab)
        frame.pack(fill="both", expand=True, pady=10)

    def show_records(self):
        queries = {
            "Faculty": "SELECT faculty_id AS ID, name AS Name, email AS Email, department AS Department FROM Faculty",
            "Students": "SELECT student_id AS ID, roll_no AS 'Roll No', name AS Name, email AS Email, "
                        "department AS Department, semester AS Semester FROM Students ORDER BY roll_no",
            "Courses": "SELECT c.course_id AS ID, c.course_code AS Code, c.course_name AS Name, c.credits AS Credits, "
                       "c.semester AS Semester, f.name AS Faculty FROM Courses c "
                       "JOIN Faculty f ON f.faculty_id = c.faculty_id ORDER BY c.course_code",
            "Attendance_Logs": "SELECT al.log_id AS 'Log ID', s.roll_no AS 'Roll No', c.course_code AS Course, "
                               "al.attendance_date AS Date, al.status AS Status FROM Attendance_Logs al "
                               "JOIN Students s ON s.student_id = al.student_id "
                               "JOIN Courses c ON c.course_id = al.course_id "
                               "ORDER BY al.attendance_date DESC, c.course_code, s.roll_no LIMIT 500",
        }
        headers, rows = self.run_query(queries[self.rec_cb.get()])
        self.fill_tree(self.rec_tree, headers, rows,
                       status_index=4 if self.rec_cb.get() == "Attendance_Logs" else None)

    # ----------------------------------------------------- refresh
    def refresh_all(self):
        courses, students = self.course_options(), self.student_options()
        self.mark_course["values"] = courses
        self.crs_cb["values"] = courses
        self.stu_cb["values"] = students
        self.crs_faculty["values"] = self.faculty_options()
        if courses and not self.mark_course.get():
            self.mark_course.current(0)
        if courses and not self.crs_cb.get():
            self.crs_cb.current(0)
        if students and not self.stu_cb.get():
            self.stu_cb.current(0)
        self.show_student_report()
        self.show_course_report()
        self.show_defaulters()
        self.show_records()

    def destroy(self):
        try:
            self.conn.close()
        except sqlite3.Error:
            pass
        super().destroy()


if __name__ == "__main__":
    AttendanceApp().mainloop()
