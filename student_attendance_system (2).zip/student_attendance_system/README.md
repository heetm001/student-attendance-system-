# Student Attendance Management System (DBMS Mini Project)

| Field | Details |
|---|---|
| Project | Student Attendance Management System |
| Tables | Students, Courses, Attendance_Logs, Faculty |
| Purpose | Record course-wise attendance daily and calculate percentage criteria per student |
| Database | SQLite |
| Front-end | Python Tkinter GUI (`gui_app.py`) + optional command-line menu (`main.py`) |

## How to run in VS Code
1. Install Python 3.8+ (and the VS Code *Python* extension). Tkinter and SQLite come with Python.
2. In VS Code: **File → Open Folder →** `student_attendance_system`.
3. **GUI (recommended):** open `gui_app.py` and press ▶ **Run**, or in the terminal:
   ```
   python gui_app.py
   ```
   **Command-line menu:** `python main.py`
4. The first run creates `attendance.db` and loads sample data automatically.
   Delete `attendance.db` to reset everything.
   (On Linux, if Tkinter is missing: `sudo apt install python3-tk`.)

### Web app (no Python needed)
Double-click `attendance_app.html` to open the full application in any browser (Chrome, Edge, Firefox).
It has the same six sections as the GUI, enforces the same keys and rules, and saves data in the browser.

### GUI tabs
| Tab | What it does |
|---|---|
| Mark Attendance | Pick course + date, load students, double-click to toggle Present/Absent, Save |
| Student Report | Course-wise and overall attendance percentage with colour-coded status |
| Course Report | All students of a course ranked by percentage |
| Defaulters | Students below 75% in any course |
| Add Records | Forms to add Student, Faculty and Course |
| View Records | Browse Faculty, Students, Courses and Attendance_Logs tables |

Optional: install the **SQLite Viewer** / **SQLite** extension to browse `attendance.db`
and run the queries in `queries.sql`.

## Files
| File | What it does |
|---|---|
| `schema.sql` | CREATE TABLE statements, constraints, indexes, and the percentage VIEW |
| `sample_data.sql` | Sample faculty, students, courses |
| `queries.sql` | Ready-made queries (percentage, defaulters, absentees, etc.) |
| `attendance_app.html` | Single-file web application (open in a browser, no install) |
| `gui_app.py` | Tkinter graphical front-end (uses the same database) |
| `main.py` | Command-line menu application and database setup |

## Database design
```
Faculty (faculty_id PK, name, email UNIQUE, department)
Students (student_id PK, roll_no UNIQUE, name, email, department, semester)
Courses (course_id PK, course_code UNIQUE, course_name, credits, department, semester,
         faculty_id FK -> Faculty)
Attendance_Logs (log_id PK, student_id FK -> Students, course_id FK -> Courses,
                 marked_by FK -> Faculty, attendance_date, status [Present|Absent],
                 UNIQUE(student_id, course_id, attendance_date))
```
Relationships
- Faculty **1 — M** Courses (a faculty teaches many courses)
- Students **1 — M** Attendance_Logs, Courses **1 — M** Attendance_Logs
  (so Students **M — N** Courses through Attendance_Logs)
- Faculty **1 — M** Attendance_Logs (who marked it)

A student belongs to a course when their *department and semester* match the course.
The design is in 3NF; the UNIQUE constraint stops duplicate entries for the same day.

## Percentage criteria
`percentage = classes_attended / total_classes × 100` (view `v_attendance_summary`)

| Percentage | Status |
|---|---|
| 75% and above | Eligible |
| 65% to below 75% | Condonation (warning) |
| Below 65% | Detained |

## Menu features
1. Mark daily attendance course-wise (enter only absentees, rest = present; re-marking a date updates it)
2. View attendance of a course on a date
3. Student report – per-course and overall percentage
4. Course report – all students ranked by percentage
5. Defaulter list (below 75%)
6. Add student / faculty / course
7. List master data

## DBMS concepts used
Primary & foreign keys, UNIQUE / CHECK / NOT NULL constraints, cascade rules, joins,
GROUP BY / aggregate functions, CASE, VIEW, indexes, UPSERT (`ON CONFLICT DO UPDATE`), transactions.
